import styled from "styled-components"

export const RoboMessage = styled.div`
  display: flex;
  justify-content: center;
  min-height: 100vh;
  flex-direction: column;
`