import styled from "styled-components"

export const StoryWrapper = styled.div`
  font-size: 22px;
  margin-top: 20px;
  text-align: center;
`