import styled from "styled-components"

export const GifWrapper = styled.div`
  display: flex;
  justify-content: center;

  img {
    max-height: 300px;
  }
`