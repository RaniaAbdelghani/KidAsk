import styled from "styled-components"

export const GridLayoutItem = styled.div`
  border: solid 2px black;
`